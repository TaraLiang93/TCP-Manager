Tara Liang 108789340
Miu Ki Yip 108776319

Files/Folders in the ziped folder:
	- README.md
	- Documents
	- Part 1 
		+ TCPClient.java
		+ TCPServer.java
	- Part 2
		+ TCPClientManager.java
		+ TCPServerManager.java
		+ TCPManager.java
		+ manager.in

Once our zipped folder is unzipped, you should be able to see two folders, one file, and this README.md file. Please move the unzipped folder into your working directory. One of the folder called Part 1 will contain everything needed to test part one of the project. Please refer to System and User Documentation for instructions to compile and run part 1. Part 2 contains four files that are needed for part two of the project to function properly. Please refer to System and User Documentation within the Documents for instructions to compile and run part 2. The last file Documents contains all the documents required by this project.
